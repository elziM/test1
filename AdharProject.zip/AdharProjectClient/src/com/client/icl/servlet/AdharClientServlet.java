package com.client.icl.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBElement;

import com.icl.bean.xsd.AdharRequestBean;
import com.icl.bean.xsd.AdharResponseBean;
import com.icl.bean.xsd.ObjectFactory;
import com.icl.service.AdharService;
import com.icl.service.AdharServicePortType;

public class AdharClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest req, HttpServletResponse resp) {

		String handler = req.getParameter("handler");
		String action = req.getParameter("action");

		if (handler.equals("usermgmt")) {
			if (action.equals("userinfo")) {
				try {
					getInfo(req, resp);
				} catch (ServletException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void getInfo(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		System.out.println(" COMING 1");
		AdharResponseBean responseBean = new AdharResponseBean();
		
		AdharService aService = new AdharService();	
		AdharServicePortType adharService = aService.getAdharServiceHttpSoap11Endpoint();	
		
		AdharRequestBean requestBean = new AdharRequestBean();
		String adharno = req.getParameter("adharno");	


		ObjectFactory objF = new ObjectFactory();		
		JAXBElement<String> jaxElement = objF.createAdharResponseBeanAdharno(adharno);
		requestBean.setAdharno(jaxElement);		
		responseBean = adharService.getAdharInfo(requestBean);		
		req.setAttribute("responseBean", responseBean);
		
		System.out.println(" COMING 2");
		
		/**/
		                                                                          
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/adharinfo.jsp");
		rd.forward(req,resp) ;	

	}

}
