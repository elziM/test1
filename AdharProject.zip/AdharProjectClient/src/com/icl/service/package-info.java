/**
 * 
 * 		Please Type your service description here
 * 	
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.icl.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.icl.service;
