@javax.xml.bind.annotation.XmlSchema(namespace = "http://bean.icl.com/xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.icl.bean.xsd;
