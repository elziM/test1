
package com.icl.bean.xsd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.icl.bean.xsd package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AdharResponseBeanPath_QNAME = new QName("http://bean.icl.com/xsd", "path");
    private final static QName _AdharResponseBeanAdharno_QNAME = new QName("http://bean.icl.com/xsd", "adharno");
    private final static QName _AdharResponseBeanEmail_QNAME = new QName("http://bean.icl.com/xsd", "email");
    private final static QName _AdharResponseBeanAddress_QNAME = new QName("http://bean.icl.com/xsd", "address");
    private final static QName _AdharResponseBeanName_QNAME = new QName("http://bean.icl.com/xsd", "name");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.icl.bean.xsd
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AdharResponseBean }
     * 
     */
    public AdharResponseBean createAdharResponseBean() {
        return new AdharResponseBean();
    }

    /**
     * Create an instance of {@link AdharRequestBean }
     * 
     */
    public AdharRequestBean createAdharRequestBean() {
        return new AdharRequestBean();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "path", scope = AdharResponseBean.class)
    public JAXBElement<String> createAdharResponseBeanPath(String value) {
        return new JAXBElement<String>(_AdharResponseBeanPath_QNAME, String.class, AdharResponseBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "adharno", scope = AdharResponseBean.class)
    public JAXBElement<String> createAdharResponseBeanAdharno(String value) {
        return new JAXBElement<String>(_AdharResponseBeanAdharno_QNAME, String.class, AdharResponseBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "email", scope = AdharResponseBean.class)
    public JAXBElement<String> createAdharResponseBeanEmail(String value) {
        return new JAXBElement<String>(_AdharResponseBeanEmail_QNAME, String.class, AdharResponseBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "address", scope = AdharResponseBean.class)
    public JAXBElement<String> createAdharResponseBeanAddress(String value) {
        return new JAXBElement<String>(_AdharResponseBeanAddress_QNAME, String.class, AdharResponseBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "name", scope = AdharResponseBean.class)
    public JAXBElement<String> createAdharResponseBeanName(String value) {
        return new JAXBElement<String>(_AdharResponseBeanName_QNAME, String.class, AdharResponseBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "path", scope = AdharRequestBean.class)
    public JAXBElement<String> createAdharRequestBeanPath(String value) {
        return new JAXBElement<String>(_AdharResponseBeanPath_QNAME, String.class, AdharRequestBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "adharno", scope = AdharRequestBean.class)
    public JAXBElement<String> createAdharRequestBeanAdharno(String value) {
        return new JAXBElement<String>(_AdharResponseBeanAdharno_QNAME, String.class, AdharRequestBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "email", scope = AdharRequestBean.class)
    public JAXBElement<String> createAdharRequestBeanEmail(String value) {
        return new JAXBElement<String>(_AdharResponseBeanEmail_QNAME, String.class, AdharRequestBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "address", scope = AdharRequestBean.class)
    public JAXBElement<String> createAdharRequestBeanAddress(String value) {
        return new JAXBElement<String>(_AdharResponseBeanAddress_QNAME, String.class, AdharRequestBean.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://bean.icl.com/xsd", name = "name", scope = AdharRequestBean.class)
    public JAXBElement<String> createAdharRequestBeanName(String value) {
        return new JAXBElement<String>(_AdharResponseBeanName_QNAME, String.class, AdharRequestBean.class, value);
    }

}
