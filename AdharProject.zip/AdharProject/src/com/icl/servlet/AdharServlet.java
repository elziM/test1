package com.icl.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.icl.bean.AdharRequestBean;
import com.icl.bean.AdharResponseBean;
import com.icl.database.AdharDB;

/**
 * Servlet implementation class AdharServlet
 */
public class AdharServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   public void service(HttpServletRequest request,HttpServletResponse  response) throws ServletException, IOException{
	   
	  String handler=request.getParameter("handler"); 
	  String action=request.getParameter("action"); 
	  
	  if(handler.equals("adharMgmt")){
		  
		  if(action.equals("getInfo")){
			  
			  getAdharInfo(request,response);
			  
		  }
	  } 
	   
	   
   }
   public void getAdharInfo(HttpServletRequest request,HttpServletResponse  response) throws ServletException, IOException{
	   AdharRequestBean requestBean= new AdharRequestBean();
	   RequestDispatcher rd= null;
	   AdharDB adharDb= new AdharDB();
	   String adharno=request.getParameter("adharno");	 
	   
	   System.out.println(" Number is : "+ adharno);
	   requestBean.setAdharno(adharno);	   
	   AdharResponseBean adharBean=adharDb.getAdharInfo(requestBean);
	   request.setAttribute("adharBean",adharBean);	   
	   rd=getServletContext().getRequestDispatcher("/adharinfo.jsp");
	   rd.forward(request,response);
			   
	   
	   
	   
	   
   }
}
