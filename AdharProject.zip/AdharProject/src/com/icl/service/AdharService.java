package com.icl.service;

import com.icl.bean.AdharRequestBean;
import com.icl.bean.AdharResponseBean;
import com.icl.database.AdharDB;

public class AdharService {
	
	
	public AdharResponseBean getAdharInfo(AdharRequestBean requestBean){
	
	AdharDB adharDB= new AdharDB();
	
	return adharDB.getAdharInfo(requestBean);
	

}
}
