package com.icl.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import com.icl.bean.AdharRequestBean;
import com.icl.bean.AdharResponseBean;



public class AdharDB {
	
	
		Connection con;
		private Connection getConnection()
		{
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:XE", "ADHAR", "adhar");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
			
			 
		}
		public AdharResponseBean getAdharInfo(AdharRequestBean  requestBean){
		System.out.println(" Ind db before conn");
		Connection con=getConnection();
		AdharResponseBean responseBerann = new AdharResponseBean();
		Statement stmt= null;
		ResultSet rs= null;		
		System.out.println("verifyQuery");
		try {
			stmt=con.createStatement();
				
					String query1="select adharno,name,address,emailid,photopath from adhar_t  where adharno='"+requestBean.getAdharno()+"'";
					rs=stmt.executeQuery(query1);
					while(rs.next()){
						System.out.println("Inside DB");
						String adno=rs.getString("adharno");
						
						String name=rs.getString("name");
						String add=rs.getString("address");
						String email=rs.getString("emailid");					
					    String phot=rs.getString("photopath");					    
					    String a=phot;
					    responseBerann.setAdharno(adno);
					    responseBerann.setAddress(add);
					    responseBerann.setName(name);
					    responseBerann.setEmail(email);					   
					    responseBerann.setPath(a);
						
					
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return responseBerann;
			
		}

}
