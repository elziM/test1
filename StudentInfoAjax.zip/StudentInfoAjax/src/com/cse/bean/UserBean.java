package com.cse.bean;

public class UserBean {

	private String fname = "";
	private String lname = "";
	private String address = "";
	private String email = "";
	private String dob = "";
	private String usn = "";
	private String loginName = "";
	private String password = "";
	
	private String loginErrorMsg = "";
	
	private String generalErrMsg="";
	
	private int courseId = 0;
	private int semId  = 0;
	private int batchId  = 0;
	private int userId  = 0;
	
	private int generalErrFlg=0;
	private int usnErrFlg=0;
	private int loginErrFlg=0;
	
	private int fnameErrFlg=0;
	private int lnameErrFlg=0;
	private int dobErrFlg=0;
	private int emailErrFlg=0;
	private int addressErrFlg=0;
	
	private String errMessage = "";
	private String fnameErrMsg = "";
	private String emailErrMsg = "";
	private String dobErrMsg = "";
	private String lnameErrMsg = "";
	private String USNErrorMsg = "";
	private String addressErrMsg = "";
	
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getUsn() {
		return usn;
	}
	public void setUsn(String usn) {
		this.usn = usn;
	}
	
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getSemId() {
		return semId;
	}
	public void setSemId(int semId) {
		this.semId = semId;
	}
	
	public int getBatchId() {
		return batchId;
	}
	public void setBatchId(int batchId) {
		this.batchId = batchId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginErrorMsg() {
		return loginErrorMsg;
	}
	public void setLoginErrorMsg(String loginErrorMsg) {
		this.loginErrorMsg = loginErrorMsg;
	}
	public String getUSNErrorMsg() {
		return USNErrorMsg;
	}
	public void setUSNErrorMsg(String uSNErrorMsg) {
		USNErrorMsg = uSNErrorMsg;
	}
	public String getGeneralErrMsg() {
		return generalErrMsg;
	}
	public void setGeneralErrMsg(String generalErrMsg) {
		this.generalErrMsg = generalErrMsg;
	}
	public int getGeneralErrFlg() {
		return generalErrFlg;
	}
	public void setGeneralErrFlg(int generalErrFlg) {
		this.generalErrFlg = generalErrFlg;
	}
	public int getUsnErrFlg() {
		return usnErrFlg;
	}
	public void setUsnErrFlg(int usnErrFlg) {
		this.usnErrFlg = usnErrFlg;
	}
	public int getLoginErrFlg() {
		return loginErrFlg;
	}
	public void setLoginErrFlg(int loginErrFlg) {
		this.loginErrFlg = loginErrFlg;
	}
	public String getErrMessage() {
		return errMessage;
	}
	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	public int getFnameErrFlg() {
		return fnameErrFlg;
	}
	public void setFnameErrFlg(int fnameErrFlg) {
		this.fnameErrFlg = fnameErrFlg;
	}
	public int getLnameErrFlg() {
		return lnameErrFlg;
	}
	public void setLnameErrFlg(int lnameErrFlg) {
		this.lnameErrFlg = lnameErrFlg;
	}
	public int getDobErrFlg() {
		return dobErrFlg;
	}
	public void setDobErrFlg(int dobErrFlg) {
		this.dobErrFlg = dobErrFlg;
	}
	public int getEmailErrFlg() {
		return emailErrFlg;
	}
	public void setEmailErrFlg(int emailErrFlg) {
		this.emailErrFlg = emailErrFlg;
	}
	public String getFnameErrMsg() {
		return fnameErrMsg;
	}
	public void setFnameErrMsg(String fnameErrMsg) {
		this.fnameErrMsg = fnameErrMsg;
	}
	public String getEmailErrMsg() {
		return emailErrMsg;
	}
	public void setEmailErrMsg(String emailErrMsg) {
		this.emailErrMsg = emailErrMsg;
	}
	public String getDobErrMsg() {
		return dobErrMsg;
	}
	public void setDobErrMsg(String dobErrMsg) {
		this.dobErrMsg = dobErrMsg;
	}
	public String getLnameErrMsg() {
		return lnameErrMsg;
	}
	public void setLnameErrMsg(String lnameErrMsg) {
		this.lnameErrMsg = lnameErrMsg;
	}
	public int getAddressErrFlg() {
		return addressErrFlg;
	}
	public void setAddressErrFlg(int addressErrFlg) {
		this.addressErrFlg = addressErrFlg;
	}
	public String getAddressErrMsg() {
		return addressErrMsg;
	}
	public void setAddressErrMsg(String addressErrMsg) {
		this.addressErrMsg = addressErrMsg;
	}
}
