package com.cse.handler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cse.db.TestDB;

public class TestHandler extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void testLogin(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		System.out.println("in handler");
		String uname = request.getParameter("loginName");

		System.out.println("loginName is " + uname);
		//String s = request.getParameter("val");
		/*if (uname == null || uname.trim().equals("")) {
			out.print("Please enter loginName");
		} else {*/
			
			
			try {
				
				TestDB tdb = new TestDB();
				Connection con = tdb.getConnection();
				int loginCnt = 0;
				
				Statement st1 = con.createStatement();
				
				ResultSet rs1 = st1.executeQuery("select count(*)  from user_t where LOGINNAME = '"+uname+"'");
				while (rs1.next()) {
					loginCnt = rs1.getInt(1);
				}

				if (loginCnt == 0) {
						System.out.println("User Does't Exist");
					out.println("User Does't Exist");

				} else {
					System.out.println("User Exist");
					out.println("User Exist");

				}
				
				
			/*	while (rs.next()) {
					System.out.print(rs.getInt(1) + " " + rs.getString(2));
				}*/
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		//}

	}
}
