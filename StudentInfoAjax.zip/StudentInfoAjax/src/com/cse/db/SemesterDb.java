package com.cse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cse.bean.SemesterBean;

public class SemesterDb {

	private Connection getConnection() {

		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "2017mtech1",
					"mtech");

		} catch (SQLException e) {
			System.out.println("Failed to get Connection");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load Driver");
			e.printStackTrace();
		}
		return con;
	}

	public ArrayList<SemesterBean> getSemester() {

		ArrayList<SemesterBean> sList = new ArrayList<SemesterBean>();
		

		Connection con = getConnection();
		String semQuery = "select semdid, sem from sem_t";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(semQuery);
			
			while(rs.next()){
				SemesterBean sb = new SemesterBean(); 
				sb.setSemId(rs.getInt(1));
				sb.setSemester(rs.getString(2));
				sList.add(sb);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return sList;
	}

}
