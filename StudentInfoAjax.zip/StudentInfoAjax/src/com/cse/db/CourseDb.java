package com.cse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cse.bean.CourseBean;

public class CourseDb {
	
	private Connection getConnection() {

		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "2017mtech1",
					"mtech");

		} catch (SQLException e) {
			System.out.println("Failed to get Connection");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load Driver");
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<CourseBean> getCourse(){
		
		ArrayList<CourseBean> courseList = new ArrayList<CourseBean>();
		
		Connection con = getConnection();
		System.out.println("con = " + con);
		String sql = "select courseid, course from course_t";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next()){
				
				CourseBean cb = new CourseBean();
				cb.setCourseId(rs.getInt(1));
				cb.setCourse(rs.getString(2));
				courseList.add(cb);
			}
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return courseList;		
	}

}
