package com.cse.db;


public class Contact {
	 public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public int getMob() {
		return mob;
	}

	public void setMob(int mob) {
		this.mob = mob;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String fname;
	 public int mob;
	 public String lname;

	public Contact(String fname, int mob, String lname) {
		super();
		this.fname = fname;
		this.mob = mob;
		this.lname = lname;
	}

}
