package com.cse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cse.bean.BatchBean;

public class BatchDb {

	private Connection getConnection() {

		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "2017mtech1",
					"mtech");

		} catch (SQLException e) {
			System.out.println("Failed to get Connection");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load Driver");
			e.printStackTrace();
		}
		return con;
	}

	public ArrayList<BatchBean> getBatch() {

		ArrayList<BatchBean> bList = new ArrayList<BatchBean>();

		Connection con = getConnection();
		
		
		String batchQuery = "select batchid,batch from batch_t";
		
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(batchQuery);

			while(rs.next()){
				BatchBean bb = new BatchBean();
				bb.setBatchId(rs.getInt(1));
				bb.setBatch(rs.getInt(2));
				bList.add(bb);
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return bList;
	}

}
