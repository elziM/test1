package com.cse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cse.bean.LoginBean;

public class TestDB {
	public Connection getConnection() {

		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "2017mtech1",
					"mtech");

		} catch (SQLException e) {
			System.out.println("Failed to get Connection");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load Driver");
			e.printStackTrace();
		}
		return con;
	}

	public LoginBean verifyLogin(LoginBean lBean) {

		Connection con = getConnection();

		
		int loginCnt = 0;

		String loginNameQuery = "select count(*)  from user_t where LOGINNAME = '"
				+ lBean.getLoginName() + "'";
		ResultSet rs1;
		try {
			Statement st1 = con.createStatement();
			rs1 = st1.executeQuery(loginNameQuery);

			while (rs1.next()) {
				loginCnt = rs1.getInt(1);
			}

			if (loginCnt == 0) {

				lBean.setGeneralErrStatus(0);
				lBean.setGeneralErrMsg("User Does't Exist");

			} else {

				lBean.setGeneralErrStatus(1);
				lBean.setGeneralErrMsg("User Exist");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lBean;
	}
}
