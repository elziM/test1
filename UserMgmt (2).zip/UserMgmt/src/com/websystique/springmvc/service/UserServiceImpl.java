package com.websystique.springmvc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.websystique.springmvc.model.User;

@Service("userService")
public class UserServiceImpl {

	private Connection connection;

	public UserServiceImpl() {
		connection = DBUtility.getConnection();
		System.out.println("connection" + connection);
	}



	public List<User> findAllUsers() {
		List<User> users = new ArrayList<User>();
		try {
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery("select * from EMPMGMT");

			while (rs.next()) {
				User user = new User();

				user.setId(rs.getInt("empid"));

				user.setUsername(rs.getString("name"));

				user.setEmail(rs.getString("email"));

				user.setPhone(rs.getString("phoneno"));

				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}

	/*public User findById(long id) {
		for (User user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}*/
/*
	public User findByName(String name) {
		for (User user : users) {
			if (user.getUsername().equalsIgnoreCase(name)) {
				return user;
			}
		}
		return null;
	}
*/
	public void saveUser(User user) {
		int uid = 0;
		try {
			
			String maxQuery = "select max(EMPID) from EMPMGMT";
			
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(maxQuery);
			while (rs.next()) {
				uid = rs.getInt(1);
			}
			int userid = uid + 1;

			user.setId(userid);			
			
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into EMPMGMT (empid,name,email,phoneno) values (?, ?,?, ?)");

			// System.out.println("Task:"+Employee.getName());
			preparedStatement.setInt(1, (int) user.getId());
			preparedStatement.setString(2, user.getUsername());
			preparedStatement.setString(3, user.getEmail());
			preparedStatement.setString(4, user.getPhone());

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateUser(User user) {
		 try {
			 PreparedStatement preparedStatement = connection
						.prepareStatement("UPDATE EMPMGMT set name=?,email=?,phoneno=? where empid=?");

				// System.out.println("Task:"+Employee.getName());
				
				preparedStatement.setString(1, user.getUsername());
				preparedStatement.setString(2, user.getEmail());
				preparedStatement.setString(3, user.getPhone());
				preparedStatement.setInt(4, (int) user.getId());

				preparedStatement.executeUpdate();


			 } catch (SQLException e) {
			  e.printStackTrace();
			 }
    }

	public void deleteUserById(long id) {
		try {
			  System.out.println("user id "+id);
		   PreparedStatement preparedStatement = connection
		     .prepareStatement("delete from  EMPMGMT where empid =?");
		   preparedStatement.setInt(1, (int) id);
		   preparedStatement.execute();

		  } catch (SQLException e) {
		   e.printStackTrace();
		  }
		
	}
/*
	public boolean isUserExist(User user) {
		return findByName(user.getUsername()) != null;
	}
*/

}
