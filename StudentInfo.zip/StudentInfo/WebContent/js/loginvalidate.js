
function loginvalidate()
{ 
     if( document.loginform.loginname.value == "" )
   {
     alert( "Please provide your Login Name!" );
     document.loginform.loginname.focus() ;
     return false;
   }
   if( document.loginform.password.value == "" )
   {
     alert( "Please provide your password!" );
     document.loginform.password.focus() ;
     return false;
   }
   return( true );
}