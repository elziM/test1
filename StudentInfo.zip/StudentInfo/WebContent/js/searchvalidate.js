function searchvalidate() {

	if (document.searchSemBatch.Course.value == "-1") {
		alert("Please provide your Course!");

		return false;
	}

	if (document.searchSemBatch.Semester.value == "-1") {
		alert("Please provide your Semester!");

		return false;
	}
	if (document.searchSemBatch.Batch.value == "-1") {
		alert("Please provide your Batch!");

		return false;
	}

}

function search() {
	if (document.searchbyUsn.usn.value == "") {
		alert("Please provide a USN in the format ##########.");
		document.searchbyUsn.usn.focus();
		return false;
	}
}