package com.cse.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {

	private Pattern pattern;
	private Matcher matcher;

	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static final String DATE_PATTERN = "(0?[1-9]|[12][0-9]|3[01])/(0?[1-9]|1[012])/((19|20)\\d\\d)";

	private static final String NAME_PATTERN = "^[a-zA-Z]+?[a-zA-Z .]*?[ a-zA-Z.]*?";
			//"^[a-zA-Z ]*";
	// 1SI15SCS08
	private static final String USN_PATTERN = "(1)[A-Z]{2}\\d{2}(SCS|SIS|SEC|SME|SCN)\\d{3}";
	
	private static final String ADDRESS_PATTERN = "[0-9a-zA-Z #,-]*{255}";

	public boolean isEmail(final String email) {

		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(email);
		return matcher.matches();
	}

	public boolean isDate(String date) {

		pattern = Pattern.compile(DATE_PATTERN);
		matcher = pattern.matcher(date);

		if (matcher.matches()) {

			matcher.reset();

			if (matcher.find()) {

				String day = matcher.group(1);
				String month = matcher.group(2);
				int year = Integer.parseInt(matcher.group(3));

				if (day.equals("31")
						&& (month.equals("4") || month.equals("6")
								|| month.equals("9") || month.equals("11")
								|| month.equals("04") || month.equals("06") || month
									.equals("09"))) {
					return false; // only 1,3,5,7,8,10,12 has 31 days
				} else if (month.equals("2") || month.equals("02")) {
					// leap year
					if (year % 4 == 0) {
						if (day.equals("30") || day.equals("31")) {
							return false;
						} else {
							return true;
						}
					} else {
						if (day.equals("29") || day.equals("30")
								|| day.equals("31")) {
							return false;
						} else {
							return true;
						}
					}
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public boolean isName(String fname) {
		// String regx = "^[\\p{L} .'-]+$";

		// String regx = "\\w+\\s{1}";
		System.out.println("First name is : " + fname);

		pattern = Pattern.compile(NAME_PATTERN, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(fname);
		System.out.println("First name is : " + fname);
		return matcher.find();
	}

	public boolean isUSN(String usn) {

		pattern = Pattern.compile(USN_PATTERN);
		Matcher matcher = pattern.matcher(usn);
		return matcher.find();

	}
	
	public boolean isValidAddress(String address) {

		pattern = Pattern.compile(ADDRESS_PATTERN);
		Matcher matcher = pattern.matcher(address);
		return matcher.find();

	}
}
