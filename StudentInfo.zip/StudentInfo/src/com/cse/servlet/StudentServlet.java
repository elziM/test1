package com.cse.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cse.bean.LoginBean;
import com.cse.handler.StudentHandler;
import com.cse.handler.SubjectHandler;

// TODO: Auto-generated Javadoc
/**
 * The Class StudentServlet.
 */
public class StudentServlet extends HttpServlet {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The handler. */
	private String handler;

	/** The action. */
	private String action;


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#service(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		handler = request.getParameter("handler");

		action = request.getParameter("action");

		if (handler != null) {
			handler = handler.trim();
		}
		if (action != null) {
			action = action.trim();
		}

		System.out.println("handler = " + handler + " :::::: action = "
				+ action);

		if (handler.equals("loginMgmt")) {

			if (action.equals("getLoginPage")) {
				getLoginPage(request, response);
			} else if (action.equals("verifyLogin")) {
				verifyLogin(request, response);
			} else if (action.equals("logout")) {

			} else if (action.equals("changePassword")) {

			}
		} 
		else if (handler.equals("StudentMgmt")) {

			if (action.equals("getStdRegForm")) {
				getStdRegForm(request, response);
			} else if (action.equals("regStudent")) {
				regStudent(request, response);
			} else if (action.equals("searchStudentInfo")) {
				searchStudentInfo(request,response);
			} else if (action.equals("searchStudentByUsn")) {
				searchStudentByUsn(request,response);
			}else if (action.equals("getModForm")) {
				getModForm(request,response);
			}else if (action.equals("modStudent")) {
				modStudent(request,response);
			}else if (action.equals("delStudent")){
				delStudent(request,response);
			}

		} else if (handler.equals("regMgmt")) {
			if (action.equals("verifySub")) {
				verifySub(request,response);
			}
		}
	}

	/**
	 * Verify sub.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void verifySub(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		SubjectHandler sh = new SubjectHandler();
		sh.verifySub(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/test.jsp");
		rd.forward(request, response);
		return;
		
	}

	/**
	 * Gets the login page.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the login page
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private final void getLoginPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/Login.jsp");
		rd.forward(request, response);
		return;
	}

	/**
	 * Gets the std reg form.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the std reg form
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private final void getStdRegForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		StudentHandler sh = new StudentHandler();
		sh.getStdRegForm(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/StudentReg.jsp");
		rd.forward(request, response);
		return;
	}

	/**
	 * Register the student.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private final void regStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		StudentHandler sh = new StudentHandler();
		int status = sh.registerStudent(request, response);
		if (status == 1) {
			request.getRequestDispatcher("/StudentReg.jsp").forward(request,
					response);
		} else {
			request.setAttribute("success", "Student Registered Successfully.");
			RequestDispatcher rd = getServletContext().getRequestDispatcher(
					"/Login.jsp");
			rd.forward(request, response);
		}
		return;
	}

	/**
	 * Verify login.
	 *
	 * @param request            the request
	 * @param response            the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void verifyLogin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.verifyLogin(request, response);

		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/Welcome.jsp");
		rd.forward(request, response);

	}

	/**
	 * Search student info.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void searchStudentInfo(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.searchStudentInfo(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/Search.jsp");
		rd.forward(request, response);
	}


	/**
	 * Search student by usn.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void searchStudentByUsn(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.searchStudentByUsn(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/searchByUSN.jsp");
		rd.forward(request, response);
	}

	/**
	 * Gets the mod form.
	 *
	 * @param request the request
	 * @param response the response
	 * @return the mod form
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void getModForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.getModForm(request, response);

		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/StudentMod.jsp");
		rd.forward(request, response);	

	}

	/**
	 * updates the student.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void modStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.modStudent(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/Search.jsp");
		rd.forward(request, response);

	}
	
	/**
	 * Del student.
	 *
	 * @param request the request
	 * @param response the response
	 * @throws ServletException the servlet exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private void delStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		StudentHandler sh = new StudentHandler();
		sh.delStudent(request, response);
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/Search.jsp");
		rd.forward(request, response);		
	}
	
}
