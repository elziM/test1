package com.cse.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cse.bean.BatchBean;
import com.cse.bean.CourseBean;
import com.cse.bean.LoginBean;
import com.cse.bean.SemesterBean;
import com.cse.bean.UserBean;
import com.cse.db.BatchDb;
import com.cse.db.CourseDb;
import com.cse.db.SemesterDb;
import com.cse.db.StudentDb;
import com.cse.validator.Validator;

// TODO: Auto-generated Javadoc
/**
 * The Class StudentHandler.
 *
 * @author icl
 */
public class StudentHandler extends HttpServlet {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Gets the std reg form.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the std reg form
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public void getStdRegForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		CourseDb db = new CourseDb();
		SemesterDb sdb = new SemesterDb();
		BatchDb bdb = new BatchDb();

		ArrayList<CourseBean> cList = db.getCourse();
		request.setAttribute("cList", cList);

		ArrayList<SemesterBean> sList = sdb.getSemester();
		request.setAttribute("sList", sList);

		ArrayList<BatchBean> bList = bdb.getBatch();
		request.setAttribute("bList", bList);

	}

	/**
	 * Register student.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the int
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public int registerStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		UserBean uBean = new UserBean();
		Validator validate = new Validator();
		int status = 0;

		String fName = request.getParameter("studentname");
		String lName = request.getParameter("lastname");
		String address = request.getParameter("paddress").trim();
		// String gender = request.getParameter("gender");

		int courseId = Integer.parseInt(request.getParameter("Course"));
		int semId = Integer.parseInt(request.getParameter("Semester"));
		int batch = Integer.parseInt(request.getParameter("Batch"));

		String usn = request.getParameter("usn");
		String email = request.getParameter("emailid");
		String dob = request.getParameter("dob");
		String loginName = request.getParameter("loginname");
		String password = request.getParameter("password");

	

		//System.out.println("name: " + validate.isName(fName));
		if (!validate.isName(fName)) {
			System.out.println("Inside error  : " + validate.isName(fName));
			uBean.setFnameErrFlg(1);
			uBean.setFnameErrMsg("Incorrect First Name.");
		}

		if (!validate.isName(lName.trim())) {
			System.out.println("Inside error  : " + validate.isName(lName));
			uBean.setLnameErrFlg(1);
			uBean.setLnameErrMsg("Incorrect Last Name.");
		}

		//System.out.println(" address -- " + address);
		if (!validate.isValidAddress(address)) {
			uBean.setAddressErrFlg(1);
			uBean.setAddressErrMsg("Incorrect Address.");
		}
		//System.out.println(" address -- " + address);
		
		if (!validate.isEmail(email)) {
			uBean.setEmailErrFlg(1);
			uBean.setEmailErrMsg("Incorrect Email address.");
		}

		if (!validate.isDate(dob)) {
			uBean.setDobErrFlg(1);
			uBean.setDobErrMsg("Incorrect Date of Birth.");
		}

		if (!validate.isUSN(usn)) {
			uBean.setUsnErrFlg(1);
			uBean.setUSNErrorMsg("Incorrect USN.");
		}
		System.out.println(" name is : " + fName);
		System.out.println("before setting : ");
		uBean.setFname(fName);
		System.out.println("afetr setting : " + uBean.getFname());
		uBean.setLname(lName);
		uBean.setAddress(address);
		uBean.setEmail(email);
		uBean.setDob(dob);
		uBean.setUsn(usn);

		uBean.setSemId(semId);
		uBean.setBatchId(batch);
		uBean.setCourseId(courseId);

		uBean.setLoginName(loginName);
		uBean.setPassword(password);

		System.out.println("Flag is : " + uBean.getFnameErrFlg());
		if (uBean.getFnameErrFlg() != 1 && uBean.getDobErrFlg() != 1
				&& uBean.getLnameErrFlg() != 1 && uBean.getAddressErrFlg() != 1
				&& uBean.getEmailErrFlg() != 1 && uBean.getUsnErrFlg()!=1) {
			StudentDb stddb = new StudentDb();
			uBean = stddb.regStudent(uBean);

			System.out
					.println("--- flag are  : login: " + uBean.getLoginErrFlg()
							+ " usn : " + uBean.getUsnErrFlg());

			if (uBean.getLoginErrFlg() == 1) {
				getStdRegForm(request, response);

				uBean.setLoginErrorMsg("LoginName already exists.");
				status = 1;
			}
			if (uBean.getUsnErrFlg() == 1) {

				getStdRegForm(request, response);

				uBean.setUSNErrorMsg("USN already exists.");
				status = 1;
			}
			if (uBean.getGeneralErrFlg() == 1) {
				uBean.setGeneralErrMsg("Unsuccessfull registration.");
				status = 1;
			}
		} else {
			getStdRegForm(request, response);
			status = 1;
		}
		request.setAttribute("uBean", uBean);
		/*
		 * if (status == 1) System.out.println("Student updated Successfully.");
		 * else System.out.println("Unsuccessfull updation.");
		 */
		return status;

	}

	/**
	 * Verify login.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the login bean
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public LoginBean verifyLogin(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		LoginBean lBean = new LoginBean();

		String loginName = request.getParameter("loginname");
		String password = request.getParameter("password");
		System.out.println("User and password are -- " + loginName + " --- "
				+ password);

		lBean.setLoginName(loginName);
		lBean.setPassword(password);

		StudentDb stddb = new StudentDb();
		lBean = stddb.verifyLogin(lBean);

		request.setAttribute("lBean", lBean);
		getStdRegForm(request, response);
		return lBean;

	}

	/**
	 * Search student info.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @throws IOException
	 * @throws ServletException
	 */
	public void searchStudentInfo(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		UserBean uBean = new UserBean();

		int courseId = Integer.parseInt(request.getParameter("Course"));
		int semId = Integer.parseInt(request.getParameter("Semester"));
		int batch = Integer.parseInt(request.getParameter("Batch"));

		uBean.setSemId(semId);
		uBean.setBatchId(batch);
		uBean.setCourseId(courseId);

		StudentDb stddb = new StudentDb();
		Hashtable<String, Object> ht = stddb.getStudentInfo(uBean);
		getStdRegForm(request, response);
		request.setAttribute("ht", ht);
	}

	/**
	 * Search student by usn.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @throws IOException
	 * @throws ServletException
	 */
	public void searchStudentByUsn(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		UserBean uBean = new UserBean();

		String usn = request.getParameter("usn");

		System.out.println(" USN is " + usn);
		uBean.setUsn(usn);

		StudentDb stddb = new StudentDb();
		uBean = stddb.searchStudentByUsn(uBean);
		getStdRegForm(request, response);
		request.setAttribute("uBean", uBean);
		// System.out.println("----------------- ubea " + uBean.getUsn() +
		// " llll " + uBean.getFname());
	}

	/**
	 * Gets the mod form.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return the mod form
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public void getModForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		UserBean uBean = new UserBean();

		int userid = Integer.parseInt(request.getParameter("userid"));

		System.out.println(" USN is " + userid);
		uBean.setUserId(userid);
		StudentDb stddb = new StudentDb();
		// ArrayList<UserBean> uList = stddb.getModForm(uBean);
		uBean = stddb.getModForm(uBean);
		getStdRegForm(request, response);
		request.setAttribute("uBean", uBean);

	}

	public void modStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		UserBean uBean = new UserBean();
		int status = 0;

		String fName = request.getParameter("studentname");
		String lName = request.getParameter("lastname");
		String address = request.getParameter("paddress");
		// String gender = request.getParameter("gender");

		int courseId = Integer.parseInt(request.getParameter("Course"));
		int semId = Integer.parseInt(request.getParameter("Semester"));
		int batch = Integer.parseInt(request.getParameter("Batch"));

		int userid = Integer.parseInt(request.getParameter("userid"));
		String email = request.getParameter("emailid");
		String dob = request.getParameter("dob");
		String password = request.getParameter("password");

		uBean.setFname(fName);
		uBean.setLname(lName);
		uBean.setAddress(address);
		uBean.setEmail(email);
		uBean.setDob(dob);
		uBean.setUserId(userid);

		uBean.setSemId(semId);
		uBean.setBatchId(batch);
		uBean.setCourseId(courseId);

		uBean.setPassword(password);

		StudentDb stddb = new StudentDb();
		uBean = stddb.updateStudent(uBean);

		Hashtable<String, Object> ht = stddb.getStudentInfo(uBean);
		getStdRegForm(request, response);
		request.setAttribute("ht", ht);

	}

	public void delStudent(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		Hashtable<String, Object> ht = new Hashtable<String, Object>();

		String[] ids = request.getParameterValues("delCheck");
		System.out.println(" in handler: " + ids[0]);

		StudentDb stddb = new StudentDb();
		int status = stddb.delStudent(ids);

		UserBean uBean = new UserBean();

		if (status == 0) {
			uBean.setErrMessage("No records deleted");
			ht.put("uBean", uBean);
			request.setAttribute("ht", ht);

		} else {

			// ht = stddb.getStudentInfo(uBean);
			searchStudentInfo(request, response);
		}
		// request.setAttribute("ht", ht);
	}

}
