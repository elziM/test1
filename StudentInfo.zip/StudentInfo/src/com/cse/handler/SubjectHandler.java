package com.cse.handler;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cse.bean.SubjectBean;

@SuppressWarnings("serial")
public class SubjectHandler extends HttpServlet {

	public void verifySub(HttpServletRequest request,
			HttpServletResponse response) {

		SubjectBean sb = new SubjectBean();
		String[] subSelected1 = request.getParameterValues("g1");				
		String[] subSelected2 = request.getParameterValues("g2");
		
		int cnt1 = 0;
		int cnt2 = 0;

		System.out.println("-------------"+request.getParameter("g1")+"------------------");
		
		
		if (subSelected2 != null && subSelected1 != null) {
			int subCnt1 = subSelected1.length;
			int subCnt2 = subSelected2.length;

			System.out.println(" ------ " + subCnt1 + " --- " + subCnt2);
			
			for(String s : subSelected1){
				System.out.println("Values are : " + s);
				
				if(s.equals("1")){
					
					cnt1++;
				}
				if(s.equals("2")){
				
					cnt2++;
				}
			}
			System.out.println("COUNT : " + cnt1 + " grp b : " + cnt2);
			if(cnt1 != 1){
				sb.setErrFlag(2);
				sb.setErrMsg("more than 1 subjects selected");
			}else{
				sb.setGenMsg("Registered!! No of check boxes selected : grp A " + subCnt1
						+ " grp B " + subCnt2);
			}			
			
		} else {
			
				sb.setErrFlag(2);
				sb.setErrMsg("Select subjects from both the groups.");
			
		}
	
		request.setAttribute("sb", sb);
	}
	
	
	public void verifySubByValue(HttpServletRequest request,
			HttpServletResponse response) {

		SubjectBean sb = new SubjectBean();
		String[] subSelected1 = request.getParameterValues("g1");
		String[] subSelected2 = request.getParameterValues("g2");

		if (subSelected2 != null && subSelected1 != null) {
			int subCnt1 = subSelected1.length;
			int subCnt2 = subSelected2.length;

			System.out.println(" ------ " + subCnt1 + " --- " + subCnt2);
			if (subCnt1 == 1 && subCnt2 == 1) {

				sb.setGenMsg("Registered!! No of check boxes selected : grp A " + subCnt1
						+ " grp B " + subCnt2);
			} else {
				sb.setErrFlag(1);
				sb.setErrMsg("No of subject selected is more than one for each group");
			}
		} else {
			
				sb.setErrFlag(2);
				sb.setErrMsg("Select subjects from both the groups.");
			
		}
		
		request.setAttribute("sb", sb);
	}
}
