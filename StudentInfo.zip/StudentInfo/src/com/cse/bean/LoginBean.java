package com.cse.bean;

// TODO: Auto-generated Javadoc
/**
 * The Class LoginBean.
 */
public class LoginBean {

	/** The login name. */
	String loginName ="";
	
	/** The password. */
	String password="";
	
	/** The name. */
	String name = "";
	
	/** The usn. */
	String usn="";
	
	/** The user type. */
	int userType;
	
	/** The user id. */
	int userId;
	
	/** The std login status. */
	int stdLoginStatus = 0;
	
	/** The adm login status. */
	int admLoginStatus = 0;
	
	/** The general err status. */
	int generalErrStatus =0;
	
	
	String generalErrMsg="";
	
	public String getGeneralErrMsg() {
		return generalErrMsg;
	}

	public void setGeneralErrMsg(String generalErrMsg) {
		this.generalErrMsg = generalErrMsg;
	}

	/**
	 * Gets the login name.
	 *
	 * @return the login name
	 */
	public String getLoginName() {
		return loginName;
	}
	
	/**
	 * Sets the login name.
	 *
	 * @param loginName the new login name
	 */
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	
	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * Gets the user type.
	 *
	 * @return the user type
	 */
	public int getUserType() {
		return userType;
	}
	
	/**
	 * Sets the user type.
	 *
	 * @param userType the new user type
	 */
	public void setUserType(int userType) {
		this.userType = userType;
	}
	
	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public int getUserId() {
		return userId;
	}
	
	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Gets the usn.
	 *
	 * @return the usn
	 */
	public String getUsn() {
		return usn;
	}
	
	/**
	 * Sets the usn.
	 *
	 * @param usn the new usn
	 */
	public void setUsn(String usn) {
		this.usn = usn;
	}
	
	/**
	 * Gets the std login status.
	 *
	 * @return the std login status
	 */
	public int getStdLoginStatus() {
		return stdLoginStatus;
	}
	
	/**
	 * Sets the std login status.
	 *
	 * @param stdLoginStatus the new std login status
	 */
	public void setStdLoginStatus(int stdLoginStatus) {
		this.stdLoginStatus = stdLoginStatus;
	}
	
	/**
	 * Gets the adm login status.
	 *
	 * @return the adm login status
	 */
	public int getAdmLoginStatus() {
		return admLoginStatus;
	}
	
	/**
	 * Sets the adm login status.
	 *
	 * @param admLoginStatus the new adm login status
	 */
	public void setAdmLoginStatus(int admLoginStatus) {
		this.admLoginStatus = admLoginStatus;
	}

	public int getGeneralErrStatus() {
		return generalErrStatus;
	}

	public void setGeneralErrStatus(int generalErrStatus) {
		this.generalErrStatus = generalErrStatus;
	}
	
}
