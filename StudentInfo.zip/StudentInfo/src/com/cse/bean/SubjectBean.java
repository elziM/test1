package com.cse.bean;

public class SubjectBean {

	private String subject = "";
	private String errMsg = "";
	private String genMsg = "";
	
	private int errFlag = 0;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getGenMsg() {
		return genMsg;
	}

	public void setGenMsg(String genMsg) {
		this.genMsg = genMsg;
	}

	public int getErrFlag() {
		return errFlag;
	}

	public void setErrFlag(int errFlag) {
		this.errFlag = errFlag;
	}

}
