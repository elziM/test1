package com.cse.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;

import com.cse.bean.BatchBean;
import com.cse.bean.CourseBean;
import com.cse.bean.LoginBean;
import com.cse.bean.SemesterBean;
import com.cse.bean.UserBean;

/**
 * The Class StudentDb.
 */
public class StudentDb {

	/**
	 * Gets the connection.
	 *
	 * @return the connection
	 */
	private Connection getConnection() {

		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "2017mtech1",
					"mtech");

		} catch (SQLException e) {
			System.out.println("Failed to get Connection");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load Driver");
			e.printStackTrace();
		}
		return con;
	}

	/**
	 * Reg student.
	 *
	 * @param uBean
	 *            the u bean
	 * @return the user bean
	 */
	public UserBean regStudent(UserBean uBean) {

		Connection con = getConnection();

		int flag = 0;
		int uid = 0;
		int logNameCnt = 0;
		int usnCnt = 0;
		String maxQuery = "select max(userid) from user_t";
		String loginNameQuery = "select count(LOGINNAME) as count from user_t where LOGINNAME = '"
				+ uBean.getLoginName() + "'";
		String usnQuery = "select count(USN) as usnCount from student_t where usn = '"
				+ uBean.getUsn() + "'";
		Statement stmt;
		Statement st1;
		Statement st2;
		try {

			st1 = con.createStatement();
			st2 = con.createStatement();
			ResultSet rs1 = st1.executeQuery(usnQuery);
			ResultSet rs2 = st2.executeQuery(loginNameQuery);

			while (rs1.next()) {
				usnCnt = rs1.getInt(1);
			}

			while (rs2.next()) {
				logNameCnt = rs2.getInt(1);
			}

			System.out.println(" Count is  ---usnCnt  " + usnCnt
					+ " logNameCnt " + logNameCnt);

			if (usnCnt == 1) {
				uBean.setUsnErrFlg(1);
			} else {
				uBean.setUsnErrFlg(0);
			}
			if (logNameCnt == 1) {
				uBean.setLoginErrFlg(1);
			} else {
				uBean.setLoginErrFlg(0);
			}

			System.out.println("--- flag are  : " + uBean.getLoginErrFlg()
					+ " usn" + uBean.getUsnErrFlg());

			if (uBean.getLoginErrFlg() == 0 && uBean.getUsnErrFlg() == 0) {
				System.out.println("If ucont and lcount are 0");
				stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(maxQuery);
				while (rs.next()) {
					uid = rs.getInt(1);
				}
				int userid = uid + 1;

				uBean.setUserId(userid);

				flag = 0;
				con.setAutoCommit(false);
				PreparedStatement ps1 = con
						.prepareStatement("insert into USER_T values(?,?,?,?,?)");

				ps1.setInt(1, 3);
				ps1.setInt(2, uBean.getUserId());
				ps1.setString(3, uBean.getLoginName());
				ps1.setString(4, uBean.getPassword());
				ps1.setInt(5, 1);

				ps1.executeUpdate();

				PreparedStatement ps = con
						.prepareStatement("insert into STUDENT_T values(?,?,?,?,?,?,?,?,?,?)");

				ps.setInt(1, uBean.getUserId());
				ps.setInt(2, uBean.getCourseId());
				ps.setInt(3, uBean.getSemId());
				ps.setInt(4, uBean.getBatchId());
				ps.setString(5, uBean.getFname());
				ps.setString(6, uBean.getLname());
				ps.setString(7, uBean.getUsn());
				ps.setString(8, uBean.getAddress());
				ps.setString(9, uBean.getEmail());
				ps.setString(10, uBean.getDob());

				int i = ps.executeUpdate();

				if (i > 0)
					flag = 1;
				if (flag == 0) {
					uBean.setGeneralErrFlg(1);
				}
				con.commit();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return uBean;
	}

	/**
	 * Verify login.
	 *
	 * @param lBean
	 *            the login bean
	 * @return the login bean
	 */
	@SuppressWarnings("resource")
	public LoginBean verifyLogin(LoginBean lBean) {

		Connection con = getConnection();
		Statement st1;
		int loginCnt = 0;
		int uid = 0;
		int utypeid = 0;
		String loginName = "";
		String fname = "";
		String usn = "";
		try {

			st1 = con.createStatement();
			String loginNameQuery = "select count(*)  from user_t where LOGINNAME = '"
					+ lBean.getLoginName() + "'";
			ResultSet rs1 = st1.executeQuery(loginNameQuery);
			while (rs1.next()) {
				loginCnt = rs1.getInt(1);
			}

			if (loginCnt == 0) {

				lBean.setGeneralErrStatus(0);
				lBean.setGeneralErrMsg("User Does't Exist");

			} else {

				lBean.setGeneralErrStatus(1);

				String query1 = "select userid,usertypeid from user_t where loginname= '"
						+ lBean.getLoginName()
						+ "' and password= '"
						+ lBean.getPassword() + "'";
				rs1 = st1.executeQuery(query1);
				while (rs1.next()) {
					uid = rs1.getInt(1);
					utypeid = rs1.getInt(2);

				}

				rs1.close();
				if (utypeid == 1) {

					String query2 = "select userid,usertypeid,loginname from  user_t where userid="
							+ uid + "";
					rs1 = st1.executeQuery(query2);

					while (rs1.next()) {
						uid = rs1.getInt(1);
						utypeid = rs1.getInt(2);
						loginName = rs1.getString(3);
					}
					rs1.close();
					lBean.setUserType(utypeid);
					lBean.setUserId(uid);
					lBean.setLoginName(loginName);

				} else {

					String query3 = "select user_t.userid,usertypeid,fname,usn from  user_t,student_t where user_t.userid=student_t.userid and user_t.userid="
							+ uid + "";
					rs1 = st1.executeQuery(query3);

					while (rs1.next()) {
						uid = rs1.getInt(1);
						utypeid = rs1.getInt(2);
						fname = rs1.getString(3);
						usn = rs1.getString(4);

					}

					rs1.close();

					lBean.setUserType(utypeid);
					lBean.setUserId(uid);
					lBean.setName(fname);
					lBean.setUsn(usn);

				}

			}

			/*
			 * String verifySQL = "select * from user_t where loginname='" +
			 * lBean.getLoginName() + "'";
			 * 
			 * 
			 * 
			 * while (rs1.next()) { loginCnt = rs1.getInt(1); }
			 * 
			 * if (loginCnt == 1) {
			 * 
			 * stmt = con.createStatement(); String dbLoginName = ""; String
			 * dbPassword = null;
			 * 
			 * ResultSet rs = stmt.executeQuery(verifySQL); while (rs.next()) {
			 * lBean.setUserType(rs.getInt(1)); lBean.setUserId(rs.getInt(2));
			 * dbLoginName = rs.getString(3); dbPassword = rs.getString(4);
			 * 
			 * }
			 * 
			 * System.out.println("---------"); System.out.println(" vlues : " +
			 * lBean.getLoginName() + " === " + dbLoginName);
			 * System.out.println("-----------------"); if
			 * ((lBean.getLoginName().equalsIgnoreCase(dbLoginName)) &&
			 * (lBean.getPassword().equalsIgnoreCase(dbPassword))) {
			 * 
			 * if (lBean.getUserType() == 3) { lBean.setStdLoginStatus(1);
			 * Statement st; try { st = con.createStatement(); String stdSQL =
			 * "select fname,usn from student_t where userid='" +
			 * lBean.getUserId() + "'";
			 * 
			 * ResultSet rs2 = stmt.executeQuery(stdSQL); while (rs2.next()) {
			 * lBean.setName(rs2.getString(1)); lBean.setUsn(rs2.getString(2));
			 * }
			 * 
			 * } catch (SQLException e) {
			 * 
			 * e.printStackTrace(); } } else { lBean.setAdmLoginStatus(1); } } }
			 * else { lBean.setGeneralErrStatus(1); }
			 */

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return lBean;
	}

	/**
	 * Gets the student info.
	 *
	 * @param uBean
	 *            the u bean
	 * @return the student info
	 */
	public Hashtable<String, Object> getStudentInfo(UserBean uBean) {
		Hashtable<String, Object> ht = new Hashtable<String, Object>();

		ArrayList<UserBean> userList = new ArrayList<UserBean>();

		Connection con = getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();

			String query1 = "select courseid,course from course_t where courseid="
					+ uBean.getCourseId() + "";

			ResultSet rs1 = stmt.executeQuery(query1);

			CourseBean cBean = new CourseBean();
			while (rs1.next()) {

				cBean.setCourseId(rs1.getInt(1));
				cBean.setCourse(rs1.getString(2));
			}
			ht.put("cBean", cBean);

			String query2 = "select semdid,sem from sem_t where semdid="
					+ uBean.getSemId() + "";
			ResultSet rs2 = stmt.executeQuery(query2);

			SemesterBean sBean = new SemesterBean();
			while (rs2.next()) {

				sBean.setSemId(rs2.getInt(1));
				sBean.setSemester(rs2.getString(2));
			}
			ht.put("sBean", sBean);

			String query3 = "select batchid,batch from batch_t where batchid="
					+ uBean.getBatchId() + "";

			ResultSet rs3 = stmt.executeQuery(query3);

			BatchBean bBean = new BatchBean();
			while (rs3.next()) {

				bBean.setBatchId(rs3.getInt(1));
				bBean.setBatch(rs3.getInt(2));
			}
			System.out.println("batch is  : " + bBean.getBatch());
			ht.put("bBean", bBean);

			String stdSQL = "select fname,lname,email,usn,dob,userid from student_t where  "
					+ "COURSEID= '"
					+ uBean.getCourseId()
					+ "' AND SEMDID= '"
					+ uBean.getSemId()
					+ "' AND BATCHID='"
					+ uBean.getBatchId()
					+ "'";

			System.out.println("QUERY IS " + stdSQL);
			ResultSet rs = stmt.executeQuery(stdSQL);
			while (rs.next()) {
				UserBean userBean = new UserBean();
				userBean.setFname(rs.getString(1));
				userBean.setLname(rs.getString(2));

				userBean.setEmail(rs.getString(3));
				userBean.setUsn(rs.getString(4));
				userBean.setDob(rs.getString(5));
				userBean.setUserId(rs.getInt(6));
				userList.add(userBean);
			}

			ht.put("userList", userList);

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return ht;

	}

	/**
	 * Search student by usn.
	 *
	 * @param uBean
	 *            the u bean
	 * @return the user bean
	 */
	public UserBean searchStudentByUsn(UserBean uBean) {

		Connection con = getConnection();
		Statement stmt;
		int count = 0;
		try {
			System.out.println("--- in studentdb : " + uBean.getUsn());
			stmt = con.createStatement();
			String stdSQL = "select fname,lname,COURSEID,SEMDID,BATCHID,email from student_t where usn='"
					+ uBean.getUsn() + "'";

			ResultSet rs = stmt.executeQuery(stdSQL);
			while (rs.next()) {
				++count;
				uBean.setFname(rs.getString(1));
				uBean.setLname(rs.getString(2));
				uBean.setCourseId(rs.getInt(3));
				uBean.setSemId(rs.getInt(4));
				uBean.setBatchId(rs.getInt(5));
				uBean.setEmail(rs.getString(6));
			}
			if (count == 0) {
				System.out.println(" no records");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return uBean;
	}

	public UserBean getModForm(UserBean uBean) {

		// ArrayList<UserBean> userList = new ArrayList<UserBean>();
		UserBean userBean = new UserBean();
		Connection con = getConnection();
		Statement stmt;
		try {
			System.out.println("--- in studentdb : " + uBean.getUsn());
			stmt = con.createStatement();
			String stdSQL = "select fname,lname,COURSEID,SEMDID,BATCHID,email,dob,usn,address,userid from student_t where userid='"
					+ uBean.getUserId() + "'";

			ResultSet rs = stmt.executeQuery(stdSQL);
			while (rs.next()) {

				userBean.setFname(rs.getString(1));
				userBean.setLname(rs.getString(2));
				userBean.setCourseId(rs.getInt(3));
				userBean.setSemId(rs.getInt(4));
				userBean.setBatchId(rs.getInt(5));
				userBean.setEmail(rs.getString(6));
				userBean.setDob(rs.getString(7));
				userBean.setUsn(rs.getString(8));
				userBean.setAddress(rs.getString(9));
				userBean.setUserId(rs.getInt(10));
				// userList.add(userBean);
			}

			rs.close();

			String query2 = "select loginname,password from  user_t where userid="
					+ uBean.getUserId();
			rs = stmt.executeQuery(query2);

			while (rs.next()) {
				userBean.setLoginName(rs.getString(1));
				userBean.setPassword(rs.getString(2));
			}
			rs.close();

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return userBean;

	}

	public UserBean updateStudent(UserBean uBean) {

		Connection con = getConnection();
		int flag = 0;
		try {

			con.setAutoCommit(false);

			PreparedStatement ps1 = con
					.prepareStatement("UPDATE USER_T set password = ? where userid = ?");

			ps1.setString(1, uBean.getPassword());
			ps1.setInt(2, uBean.getUserId());

			ps1.executeUpdate();

			PreparedStatement ps = con
					.prepareStatement("UPDATE STUDENT_T set COURSEID=?,SEMDID=?,BATCHID=?,FNAME=?,LNAME=?,ADDRESS=?,EMAIL=?,DOB=? where userid = ?");

			ps.setInt(1, uBean.getCourseId());
			ps.setInt(2, uBean.getSemId());
			ps.setInt(3, uBean.getBatchId());
			ps.setString(4, uBean.getFname());
			ps.setString(5, uBean.getLname());

			ps.setString(6, uBean.getAddress());
			ps.setString(7, uBean.getEmail());
			ps.setString(8, uBean.getDob());
			ps.setInt(9, uBean.getUserId());

			System.out.println("-----------------------------------"
					+ uBean.getUserId());
			int i = ps.executeUpdate();

			if (i > 0) {
				flag = 1;

			}
			if (flag == 0) {
				uBean.setGeneralErrFlg(1);
			}
			con.commit();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return uBean;
	}

	public int delStudent(String[] ids) {

		Connection con = getConnection();
		int flag = 0;
		int affectedRecords = 0;
		
		try {

			Statement st = con.createStatement();
			
			con.setAutoCommit(false);
			
			for (int i = 0; i < ids.length; i++) {
				System.out.println("ids is " + i +" -- value " + ids[i]);
				
				int userId = Integer.parseInt(ids[i]);
				st.executeUpdate("delete from student_t where userid=" + userId);
				st.executeUpdate("delete from user_t where userid=" + userId);
				affectedRecords++;
			}

			con.commit();
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return affectedRecords;
	}

}
